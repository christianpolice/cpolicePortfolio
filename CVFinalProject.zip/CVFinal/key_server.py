from flask import Flask, abort
import keyboard   # pip install flask keyboard

app = Flask(__name__)

@app.route("/press/<key_char>")
def press(key_char):
    # only allow single-character keys (or extend as needed)
    if len(key_char) != 1:
        abort(400)
    keyboard.press_and_release(key_char)
    return "OK", 200

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
