import json
import cv2
import numpy as np
import tensorflow as tf

# ─── CONFIG ─────────────────────────────────────────────────────────
SAVED_MODEL_DIR = "saved_model"
METADATA_FILE  = "metadata.json"
CONF_THRESH    = 0.90
# ────────────────────────────────────────────────────────────────────

# 1) Load metadata
with open(METADATA_FILE, "r") as f:
    meta = json.load(f)
labels = meta["labels"]

# 2) Load the TF SavedModel
model = tf.saved_model.load(SAVED_MODEL_DIR)
infer = model.signatures["serving_default"]

# 3) Helper to run inference
def classify_pose(frame):
    # frame is BGR; convert & resize to 257×257
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (257, 257)).astype(np.float32) / 255.0
    inp = tf.constant(img[None, ...])  # shape (1,257,257,3)

    # run model
    outputs = infer(inp)

    # find the 2D output tensor (1 × N)
    pred = None
    for t in outputs.values():
        arr = t.numpy()
        if arr.ndim == 2 and arr.shape[0] == 1:
            pred = arr[0]
            break
    if pred is None:
        raise RuntimeError("No classification output found")

    # also grab the pose estimation output to draw skeleton
    pose = outputs.get("output_0") or outputs.get("Identity")  # names vary by model
    # if your converted model puts the posenet output under a different key,
    # inspect `outputs.keys()` and adjust above.

    return pred, pose, img.shape[:2]  # pred (N,), pose tensor, original size

# 4) Draw keypoints & skeleton on the frame
def draw_pose_on_frame(frame, pose_output):
    # The pose_output from TFJS converter is a flat array; to re-draw
    # you’d normally need the original keypoints structure. If converting
    # from TFJS graph model didn’t preserve posenet outputs in a friendly
    # format, it can be tricky.
    #
    # **Alternative:** Use MediaPipe Pose in Python, or convert TFJS → tflite
    # with a custom signature to expose keypoints.
    #
    # For simplicity, this demo will just display classification.
    return frame

# 5) Webcam loop
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("Cannot open webcam")

last_label = None

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # classify
    pred, pose_out, _ = classify_pose(frame)
    idx  = int(np.argmax(pred))
    conf = float(pred[idx])
    lbl  = labels[idx]

    # overlay text
    color = (0,255,0) if conf >= CONF_THRESH else (0,0,255)
    text = f"{lbl}: {conf:.2f}"
    cv2.putText(frame, text, (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

    # (optional) draw pose skeleton if you can extract keypoints:
    # frame = draw_pose_on_frame(frame, pose_out)

    cv2.imshow("Pose Estimation", frame)

    if cv2.waitKey(1) & 0xFF == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
