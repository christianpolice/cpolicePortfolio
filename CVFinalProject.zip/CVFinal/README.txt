1) Start the Python key-server
In terminal #1, cd into your project folder and run:

powershell

cd C:\Users\chris\OneDrive\Desktop\CVFinal
py key_server.py
You should see:


 * Serving Flask app "key_server.py"
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
Keep this window open.

2) Serve your HTML over HTTP
In terminal #2, from the same folder run Python’s built-in server:

powershell

cd C:\Users\chris\OneDrive\Desktop\CVFinal
py -m http.server 8080
You’ll see:

nginx

Serving HTTP on :: port 8080 (http://[::]:8080/) ...
Leave this running too.

3) Open the page
In your browser go to


Edit
http://localhost:8080/yourpage.html
(replace yourpage.html with your actual HTML filename).

Click Start, then do your poses—your Python server will receive each fetch() and fire real keypresses.